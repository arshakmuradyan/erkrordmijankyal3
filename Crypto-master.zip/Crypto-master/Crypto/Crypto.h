#pragma once
#include <iostream>
using namespace std;

class Crypto {
	string s;
public:
	Crypto(string str) { s = str; }
	string dCoder() {};
	string nCoder() {};
};

